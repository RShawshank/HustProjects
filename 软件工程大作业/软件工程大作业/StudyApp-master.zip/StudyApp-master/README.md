
目的是写一个教师给学生出试题的APP

(教师可以上传自己出的试题到库里面,学生读取出来后在线答题,只能统计分数和标记出错题目。方便分析)


首页

![image text](https://github.com/lijianyou-Herve/StudyApp/blob/master/apk/art/device-2016-11-20-135401.png)

侧滑栏

![image text](https://github.com/lijianyou-Herve/StudyApp/blob/master/apk//art/device-2016-11-20-135419.png)

答题页面

![image text](https://github.com/lijianyou-Herve/StudyApp/blob/master/apk/art/device-2016-11-20-135454.png)
