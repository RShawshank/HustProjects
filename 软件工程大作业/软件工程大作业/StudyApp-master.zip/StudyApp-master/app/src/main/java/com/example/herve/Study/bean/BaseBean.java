package com.example.herve.Study.bean;

import android.os.Parcelable;


/**
 * Created           :Herve on 2016/11/4.
 *
 * @ Author          :Herve
 * @ e-mail          :lijianyou.herve@gmail.com
 * @ LastEdit        :2016/11/4
 * @ projectName     :StudyApp
 * @ version
 */
public interface BaseBean extends Parcelable {
}
