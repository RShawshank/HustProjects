package com.example.herve.Study.common;

import com.example.herve.Study.bean.AnswerSheetBean;
import com.example.herve.Study.bean.ExaminationPaperBean;

/**
 * Created           :Herve on 2016/11/7.
 *
 * @ Author          :Herve
 * @ e-mail          :lijianyou.herve@gmail.com
 * @ LastEdit        :2016/11/7
 * @ projectName     :StudyApp
 * @ version
 */
public class AppConstant {
    public static AnswerSheetBean answerSheetBean;
    public static ExaminationPaperBean examinationPaperBean;
}
